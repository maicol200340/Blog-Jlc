const AlliancesSection = () => {
  return (
    <section className="py-16 px-4 bg-gray-50">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-10 text-green-800">Alianzas y Redes</h2>
        
        <div className="bg-white p-8 rounded-xl shadow-md">
          <p className="text-lg text-gray-700 mb-6">
            Creemos en el trabajo articulado. Por eso, establecemos alianzas estratégicas con entidades públicas, 
            privadas, académicas y de cooperación internacional. Participamos en convocatorias de MinCiencias, 
            ONGs, redes de innovación y programas regionales que promueven el desarrollo sostenible.
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {/* Logos de aliados - usar imágenes reales cuando estén disponibles */}
            <div className="bg-gray-100 h-24 rounded-lg flex items-center justify-center">
              <span className="text-gray-500">MinCiencias</span>
            </div>
            <div className="bg-gray-100 h-24 rounded-lg flex items-center justify-center">
              <span className="text-gray-500">ONGs</span>
            </div>
            <div className="bg-gray-100 h-24 rounded-lg flex items-center justify-center">
              <span className="text-gray-500">Redes</span>
            </div>
            <div className="bg-gray-100 h-24 rounded-lg flex items-center justify-center">
              <span className="text-gray-500">Cooperación</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AlliancesSection;