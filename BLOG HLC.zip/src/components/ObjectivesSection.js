const ObjectivesSection = () => {
  return (
    <section className="py-16 px-4 bg-white">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-10 text-green-800">Nuestros Objetivos</h2>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-6">
            <div className="flex items-start">
              <div className="flex-shrink-0 h-6 w-6 text-green-600 mt-1 mr-3">•</div>
              <p>Promover la formación científica, tecnológica y educativa en poblaciones vulnerables y zonas rurales.</p>
            </div>
            <div className="flex items-start">
              <div className="flex-shrink-0 h-6 w-6 text-green-600 mt-1 mr-3">•</div>
              <p>Crear proyectos y participar en convocatorias de ciencia, tecnología e innovación para entidades públicas, privadas y comunitarias.</p>
            </div>
            <div className="flex items-start">
              <div className="flex-shrink-0 h-6 w-6 text-green-600 mt-1 mr-3">•</div>
              <p>Desarrollar contenidos digitales, software, videojuegos, plataformas y herramientas educativas.</p>
            </div>
          </div>
          
          <div className="space-y-6">
            <div className="flex items-start">
              <div className="flex-shrink-0 h-6 w-6 text-green-600 mt-1 mr-3">•</div>
              <p>Diseñar y ejecutar programas de formación en todos los niveles y modalidades educativas.</p>
            </div>
            <div className="flex items-start">
              <div className="flex-shrink-0 h-6 w-6 text-green-600 mt-1 mr-3">•</div>
              <p>Ofrecer servicios de consultoría en los campos de ciencia, tecnología, educación y acción social.</p>
            </div>
            <div className="flex items-start">
              <div className="flex-shrink-0 h-6 w-6 text-green-600 mt-1 mr-3">•</div>
              <p>Sensibilizar a la población sobre el cuidado ambiental y la biodiversidad.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ObjectivesSection;