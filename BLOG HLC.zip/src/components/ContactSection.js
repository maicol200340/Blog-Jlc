const ContactSection = () => {
  return (
    <section className="py-16 px-4 bg-white">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-10 text-green-800">Contáctanos</h2>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-green-700">
              ¿Te gustaría trabajar con nosotros, desarrollar un proyecto conjunto o apoyar nuestras iniciativas?
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="text-green-600 mr-3 mt-1">📧</div>
                <div>
                  <p className="font-medium">Correo electrónico</p>
                  <p className="text-gray-600">fundacionjlc@gmail.com</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="text-green-600 mr-3 mt-1">📱</div>
                <div>
                  <p className="font-medium">Teléfonos</p>
                  <p className="text-gray-600">318 744 5983 | 317 664 4624</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="text-green-600 mr-3 mt-1">📍</div>
                <div>
                  <p className="font-medium">Dirección</p>
                  <p className="text-gray-600">Calle 17 No. 6-87, Barrio Siete de Agosto, Florencia, Caquetá</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 p-6 rounded-xl">
            <h4 className="text-lg font-semibold mb-4 text-green-700">Envíanos un mensaje</h4>
            <form className="space-y-4">
              <div>
                <input 
                  type="text" 
                  placeholder="Nombre completo" 
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div>
                <input 
                  type="email" 
                  placeholder="Correo electrónico" 
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div>
                <textarea 
                  placeholder="Mensaje" 
                  rows="4"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                ></textarea>
              </div>
              <button 
                type="submit"
                className="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors"
              >
                Enviar mensaje
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;