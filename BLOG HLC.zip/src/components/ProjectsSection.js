const ProjectsSection = () => {
  const projects = [
    {
      title: "Raíces Digitales",
      year: "2023",
      description: "Capacitamos a más de 200 jóvenes rurales en herramientas digitales, creación de contenido y uso responsable de tecnologías, fomentando el emprendimiento local y la inclusión digital.",
      impact: "200+ beneficiarios"
    },
    {
      title: "Formación Ambiental",
      year: "2022-Presente",
      description: "Programa para generar conciencia ambiental en niños, jóvenes y adultos mediante talleres y salidas pedagógicas.",
      impact: "Comunidades educativas"
    }
  ];

  return (
    <section className="py-16 px-4 bg-white">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12 text-green-800">Proyectos Representativos</h2>
        
        <div className="space-y-8">
          {projects.map((project, index) => (
            <div key={index} className="relative pl-8 border-l-4 border-green-600">
              <div className="absolute -left-3.5 top-0 w-6 h-6 rounded-full bg-green-600"></div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-4">
                  <h3 className="text-xl font-bold text-green-800">{project.title}</h3>
                  <span className="text-sm font-medium bg-green-100 text-green-800 px-3 py-1 rounded-full">
                    {project.year}
                  </span>
                </div>
                <p className="text-gray-700 mb-3">{project.description}</p>
                <p className="text-sm font-medium text-green-700">Impacto: {project.impact}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;