const AboutSection = () => {
  return (
    <section className="py-16 px-4 bg-gray-50">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-10 text-green-800">¿Quiénes Somos?</h2>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <p>
              La Fundación JLC es una entidad sin ánimo de lucro con sede en Florencia, Caquetá,
              que trabaja desde el año 2015 en el desarrollo de procesos científicos,
              tecnológicos, educativos, ambientales y sociales.
            </p>
            <p>
              Nuestro objetivo principal es mejorar la calidad de vida de la población
              a través de proyectos innovadores, accesibles y sostenibles.
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-4 text-green-700">Información Legal</h3>
            <ul className="space-y-2">
              <li><span className="font-medium">NIT:</span> 900.917.770-4</li>
              <li><span className="font-medium">Fecha de constitución:</span> 14/12/2015</li>
              <li><span className="font-medium">Dirección:</span> Calle 17 No. 6 - 87, Siete de Agosto, Florencia</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;